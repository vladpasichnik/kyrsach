package model;

import lombok.Data;

import java.time.LocalDateTime;
import java.util.Scanner;


@Data
public class Dealer extends User {
    private Company company;
    private String city;


    public void carRegistration() {
        Scanner scanner = new Scanner(System.in);
        Car car = new Car();

        System.out.print("\nEnter car model:");
        car.setModel(scanner.nextLine());
        System.out.print("Enter car registration number:");
        car.setCarNumber(scanner.next());
        System.out.print("Enter car year:");
        car.setYear(scanner.nextInt());
        System.out.print("Enter car race:");
        car.setRace(scanner.nextInt());

        company.getGarage().addCar(car);
    }


    public void createOrder() {
        Scanner scanner = new Scanner(System.in);
        Order order = new Order();

        Client currentClient = getClient();
        order.setClient(currentClient);

        System.out.print("Enter car model:");
        order.setId(System.currentTimeMillis());
        order.setCar(company.getGarage().getCar());
        order.setCreated(LocalDateTime.now());

        System.out.print("Enter days amount:");
        order.setDays(scanner.nextInt());

        currentClient.getOrders().add(order);
    }

    public void showAllOrders() {

        for (int i = 0; i < company.getClients().size(); i++) {
            System.out.println(company.getClients().get(i).toString());
        }
    }

    public void showClients() {
        for (int i = 0; i < company.getClients().size(); i++) {
            System.out.println("#" + i + " " + company.getClients().get(i).getClientInfo());
        }
    }


    public Client getClient() {
        Scanner scanner = new Scanner(System.in);
        showClients();
        System.out.print("Choose client by number:");
        int client = scanner.nextInt();
        return company.getClients().get(client);
    }


}
