package model;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class Client extends User {
    private String name;
    private String driverIdNumber;
    private List<Order> orders = new ArrayList<>();

    public String getClientInfo(){
        return "Client{" +
                "name='" + name + '\'' +
                ", driverIdNumber='" + driverIdNumber + '}';
    }

    @Override
    public String toString() {
        return "Client{" +
                "name='" + name + '\'' +
                ", driverIdNumber='" + driverIdNumber + '\'' +
                "\n orders=" + orders +
                '}';
    }
}
