package model;

import lombok.Data;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

@Data
public class Garage implements Serializable {
    private static final long serialVersionUID = 4L;
    private List<Car> cars = new ArrayList<>();

    public void addCar(Car car) {
        cars.add(car);
    }

    public void showAllCars() {
        System.out.println("\nALL CARS");
        for (int i = 0; i < cars.size(); i++) {
            System.out.print("#" + i + " ");
            System.out.println(cars.get(i).toString());
        }
    }

    public void showFreeCars() {
        System.out.println("\nFREE CARS");
        for (int i = 0; i < cars.size(); i++) {
            if (cars.get(i).isFree()) {
                System.out.print("#" + i + " ");
                System.out.println(cars.get(i).toString());
            }
        }
    }

    public Car getCar() {
        Scanner scanner = new Scanner(System.in);
        showFreeCars();
        System.out.print("Choose car by number:");
        int carNumber = scanner.nextInt();
        Car current = cars.get(carNumber);
        current.setFree(false);
        return current;
    }

}
