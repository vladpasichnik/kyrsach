package model;

import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;

@Data
public class Order implements Serializable {
    private static final long serialVersionUID = 5L;

    private long id;
    private Car car;
    private Client client;
    private LocalDateTime created;
    private int days;
    private int payment;
    private boolean isClosed;

    @Override
    public String toString() {
        return "\nOrder{" +
                "id=" + id +
                ", car=" + car +
                ", created=" + created +
                ", days=" + days +
                ", isClosed=" + isClosed +
                '}';
    }
}
