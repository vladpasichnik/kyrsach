package model;

import lombok.Data;

import java.io.Serializable;

@Data
public class Car implements Serializable {
    private static final long serialVersionUID = 3L;
    private String carNumber;
    private String model;
    private int year;
    private int race;
    private boolean isFree = true;
}
