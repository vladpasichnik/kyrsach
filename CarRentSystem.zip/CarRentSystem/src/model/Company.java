package model;

import lombok.Data;
import menu.MainMenu;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

@Data
public class Company implements Serializable {
    private static final long serialVersionUID = 1L;
    private List<Dealer> dealers = new ArrayList<>();
    private List<Client> clients = new ArrayList<>();
    private Garage garage = new Garage();


    public void addNewClient() {
        Scanner scanner = new Scanner(System.in);

        Client client = new Client();
        client.setId(System.currentTimeMillis());

        System.out.print("\nEnter client name: ");
        client.setName(scanner.next());

        System.out.print("Enter client phone: ");
        client.setPhoneNumber(scanner.next());

        System.out.print("Enter client password: ");
        client.setPassword(scanner.next());

        System.out.print("Enter client driver license number: ");
        client.setDriverIdNumber(scanner.next());

        clients.add(client);
        System.out.println("NEW USER WAS CREATED!!!\n");

        MainMenu.callMenu();
    }

    public void addNewDealer() {
        Scanner scanner = new Scanner(System.in);

        Dealer dealer = new Dealer();
        dealer.setId(System.currentTimeMillis());

        System.out.print("\nEnter dealer phone: ");
        dealer.setPhoneNumber(scanner.next());

        System.out.print("Enter dealer password: ");
        dealer.setPassword(scanner.next());

        System.out.print("Enter dealer city: ");
        dealer.setCity(scanner.next());

        dealer.setCompany(this);
        dealers.add(dealer);

        System.out.println("NEW DEALER WAS CREATED!!!\n");

        MainMenu.callMenu();
    }


    public static Company loadCompanyInfo(String path) {
        Company company = null;
        try {
            FileInputStream file = new FileInputStream(path);
            ObjectInputStream in = new ObjectInputStream(file);
            company = (Company) in.readObject();

            in.close();
            file.close();
        } catch (IOException ex) {
            System.out.println("IOException is caught");
        } catch (ClassNotFoundException ex) {
            System.out.println("ClassNotFoundException is caught");
        }
        return company;
    }

    public static void saveCompanyInfo(Company company, String path) {

        try {
            FileOutputStream file = new FileOutputStream(path);
            ObjectOutputStream out = new ObjectOutputStream(file);
            out.writeObject(company);
            out.close();
            file.close();

        } catch (IOException ex) {
            System.out.println("IOException is caught");
        }
    }


}
