package model;

import lombok.Data;

import java.io.Serializable;

@Data
public class User  implements Serializable {
    private static final long serialVersionUID = 2L;
    private long id;
    private String phoneNumber;
    private String password;
}
