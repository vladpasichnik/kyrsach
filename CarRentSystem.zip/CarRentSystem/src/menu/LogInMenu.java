package menu;

import model.Dealer;

import java.util.Scanner;

public class LogInMenu {
    public static void callMenu() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter phone: ");
        String phone = scanner.next();

        System.out.print("Enter password: ");
        String password = scanner.next();

        for (int i = 0; i < MainMenu.company.getDealers().size(); i++) {
            Dealer dealer = MainMenu.company.getDealers().get(i);
            if (dealer.getPhoneNumber().equals(phone)) {
                if (dealer.getPassword().equals(password)) {
                    DealerMenu.callMenu(dealer);
                }
            }
        }
        System.out.println("WRONG LOGIN OR PASSWORD");

    }
}
