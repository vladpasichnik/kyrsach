package menu;

import java.util.Scanner;

public class RegistrationMenu {
    public static void callMenu() {
        showMenu();
        do {
            doAction(chooseMenu());
        } while (true);
    }

    public static void showMenu() {
        System.out.println("\nREGISTRATION MENU");
        System.out.println("1 - New Dealer");
        System.out.println("2 - New Client");
        System.out.println("0 - Back");
    }

    public static int chooseMenu() {
        System.out.print("\nEnter menu number :");
        return new Scanner(System.in).nextInt();
    }

    public static void doAction(int menu) {
        switch (menu) {
            case 1:
                MainMenu.company.addNewDealer();
                break;
            case 2:
                MainMenu.company.addNewClient();
                break;
            case 0:
                MainMenu.callMenu();
            default:
                System.out.println("WRONG MENU NUMBER");
        }
    }
}
