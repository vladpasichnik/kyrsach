package menu;

import model.Car;
import model.Client;
import model.Company;
import model.Dealer;

import java.util.Scanner;

public class MainMenu {


    public static Company company;

    public static void main(String[] args) {
        initCompany();
        callMenu();
    }

    public static void callMenu() {

        do {
            showMenu();
            doAction(chooseMenu());
            Company.saveCompanyInfo(company, "company.ser");
        } while (true);
    }

    public static void showMenu() {
        System.out.println("\nMAIN MENU");
        System.out.println("1 - LogIn");
        System.out.println("2 - Registration");
        System.out.println("0 - Exit");
    }

    public static int chooseMenu() {
        System.out.print("\nEnter menu number :");
        return new Scanner(System.in).nextInt();
    }

    public static void doAction(int menu) {
        switch (menu) {
            case 1:
                LogInMenu.callMenu();
                break;
            case 2:
                RegistrationMenu.callMenu();
                break;
            case 0:
                Company.saveCompanyInfo(company, "company.ser");
                System.exit(0);
            default:
                System.out.println("WRONG MENU NUMBER");

        }
    }

    public static void initCompany() {

        company = Company.loadCompanyInfo("company.ser");
        if (company == null) {

            company = new Company();

            Dealer dealer = new Dealer();
            dealer.setId(System.currentTimeMillis());
            dealer.setPhoneNumber("0682");
            dealer.setPassword("12345");
            dealer.setCity("Kyiv");
            dealer.setCompany(company);

            company.getDealers().add(dealer);

            Client client = new Client();
            client.setDriverIdNumber("PU105023");
            client.setName("Taras");
            client.setPhoneNumber("0974");
            client.setPassword("54321");
            client.setId(System.currentTimeMillis());
            company.getClients().add(client);

            Car car1 = new Car();
            car1.setModel("Tesla model X");
            car1.setCarNumber("ВХ77777");
            car1.setYear(2016);
            car1.setRace(15000);
            car1.setFree(true);
            company.getGarage().addCar(car1);

            Car car2 = new Car();
            car2.setModel("BMW X6");
            car2.setCarNumber("ВХ666");
            car2.setYear(2017);
            car2.setRace(1500);
            car2.setFree(true);
            company.getGarage().addCar(car2);
        }


    }
}
