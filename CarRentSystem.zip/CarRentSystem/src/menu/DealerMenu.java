package menu;

import model.Dealer;

import java.util.Scanner;

public class DealerMenu {
    private static Dealer currentDealer;

    public static void callMenu(Dealer dealer) {
        currentDealer = dealer;

        do {
            showMenu();
            doAction(chooseMenu());
        } while (true);
    }


    public static void showMenu() {
        System.out.println("\nDEALER MENU");
        System.out.println("1 - New Car Registration");
        System.out.println("2 - New Client");
        System.out.println("3 - New order");
        System.out.println("4 - Show Cars");
        System.out.println("5 - Show clients orders");
        System.out.println("0 - Back");
    }

    public static int chooseMenu() {
        System.out.print("\nEnter menu number :");
        return new Scanner(System.in).nextInt();
    }

    public static void doAction(int menu) {
        switch (menu) {
            case 1:
                currentDealer.carRegistration();
                break;
            case 2:
                currentDealer.getCompany().addNewClient();
                break;
            case 3:
                currentDealer.createOrder();
                break;
            case 4:
                MainMenu.company.getGarage().showAllCars();
                break;
            case 5:
                currentDealer.showAllOrders();
                break;
            case 0:
                MainMenu.callMenu();
            default:
                System.out.println("WRONG MENU NUMBER");
        }
    }
}
